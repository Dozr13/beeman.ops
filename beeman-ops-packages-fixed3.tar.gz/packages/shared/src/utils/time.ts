/** Minimal helpers */
export const nowIso = () => new Date().toISOString()

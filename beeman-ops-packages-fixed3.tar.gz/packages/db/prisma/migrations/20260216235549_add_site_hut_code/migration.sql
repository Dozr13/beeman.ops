-- AlterTable
ALTER TABLE "Site" ADD COLUMN     "hutCode" TEXT;

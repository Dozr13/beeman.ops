-- DropIndex
DROP INDEX "HutAssignment_one_current_per_hut";

-- DropIndex
DROP INDEX "HutAssignment_one_current_per_site";

export * from '@prisma/client'
export { getPrisma } from './client.js'
